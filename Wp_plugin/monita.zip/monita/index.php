<?php
/**
 * Plugin Name: Monita ShortLink API
 * Plugin URI: https://monita.vn 
 * Description: Short link api for Pretty Links
 * Version: 1.0 
 * Author: Men Nguyen 
 * Author URI: https://github.com/nvmen
 * License: Only for Tibo labs
 */


//http://localhost/tibo/wp-json/monita/addshortlink
function add_shortlink($request){  
    global $wpdb;


    $param = $request->get_param( 'data' );    
    $data = explode("|", $param);
    if(count($data) !=2 ){
        return "error";
    }
    $url = $data[0];
    $code = $data[1];
    $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."prli_links WHERE slug ='".$code."'");
    $rowcount = $wpdb->num_rows;
    if($rowcount > 0){
      return "ok_existing";
    }
    $table_link = $wpdb->prefix."prli_links";
    $my_post = array(
        'post_title'    => wp_strip_all_tags($code),
        'post_content'  =>"monita  content",
        'post_status'   => 'publish',
        'post_type'     => 'pretty-link',
        'post_author'   => 1,    
      );
      $postId = wp_insert_post( $my_post );  
      wp_insert_post( $my_post );
    
        $wpdb->insert($table_link, array(
            'name' => 'monita-'. $code,
            'url' => $url,
            'slug' => $code,
            'redirect_type'=>370,
            'link_status'=>'enabled',
            'link_cpt_id'=> $postId
        ));    
        return "ok";
   
}
function my_awesome_func( $data ) {
    /*
  $my_post = array(
    'post_title'    => wp_strip_all_tags("anh yeu em khong" ),
    'post_content'  =>"monita  content",
    'post_status'   => 'publish',
    'post_type'     => 'pretty-link',
    'post_author'   => 1,    
  );
  $postId = wp_insert_post( $my_post );  
  wp_insert_post( $my_post );
  global $wpdb;
    $wpdb->insert('wp_prli_links', array(
        'name' => 'Kumkum',
        'url' => 'https://developer.wordpress.org/rest-api/extending-the-rest-api/',
        'slug' => '7230',
        'redirect_type'=>370,
        'link_status'=>'enabled',
        'link_cpt_id'=> $postId
    ));    
    return "ok";
    */
    global $wpdb;
    $slug ="996thomas-shirts";
   // $sql ="SELECT * FROM ".$wpdb->prefix."prli_links WHERE slug ='".$slug."'";
   // return $sql;
    $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."prli_links WHERE slug ='".$slug."'");
    $rowcount = $wpdb->num_rows;
    return "ok bop chim:".$rowcount;
  }
  add_action( 'rest_api_init', function () {
    register_rest_route( 'monita/v1', '/author/(?P<id>\d+)', array(
      'methods' => 'GET',
      'callback' => 'my_awesome_func',
    ) );
    register_rest_route( 'monita', '/addshortlink', array(
        'methods' => 'POST',
        'callback' => 'add_shortlink',
      ) );
  } );